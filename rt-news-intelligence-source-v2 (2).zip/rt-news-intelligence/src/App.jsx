import React, { useEffect } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import useStore from './store/useStore';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import SearchPage from './components/SearchPage';
import PublishQueue from './components/PublishQueue';
import ApiKeysManager from './components/ApiKeysManager';
import SocialAccounts from './components/SocialAccounts';
import Settings from './components/Settings';
import NewsArchive from './components/NewsArchive';

function App() {
  const { theme, fontSize } = useStore();

  useEffect(() => {
    // Apply theme class
    document.documentElement.className = `theme-${theme} text-size-${fontSize}`;
  }, [theme, fontSize]);

  return (
    <HashRouter>
      <div className={`min-h-screen theme-${theme} text-size-${fontSize}`}>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/publish" element={<PublishQueue />} />
            <Route path="/api-keys" element={<ApiKeysManager />} />
            <Route path="/social" element={<SocialAccounts />} />
            <Route path="/archive" element={<NewsArchive />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </Layout>
      </div>
    </HashRouter>
  );
}

export default App;
